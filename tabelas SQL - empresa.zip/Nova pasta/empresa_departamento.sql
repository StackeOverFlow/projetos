use empresa;

INSERT INTO departamento VALUES ('pesquisa','5','1988-05-22','333445555');

INSERT INTO departamento VALUES ('Gerencia','1','1981-06-19','888665555');

INSERT INTO departamento VALUES ('Adm','4','1999-01-01','987654321');

INSERT INTO empregado VALUES ('John','B','Smith','123456789','1965-01-09','...','M','30000','333445555',5);

INSERT INTO empregado VALUES ('Franklin','T','Wong','333445555','1955-12-08','...','M','40000','888665555',5);

INSERT INTO empregado VALUES ('Alicia','J','Zelaya','999887777','1968-07-19','...','F','250000','987654321',4);

INSERT INTO empregado VALUES ('Jennifer','S','Wallace','987654321','1941-06-20','...','F','43000','888665555',4);

INSERT INTO empregado VALUES ('Ramesh','K','Narayan','666884444','1962-09-15','...','M','38000','333445555',5);

INSERT INTO empregado VALUES ('Joyce','A','English','453453453','1972-07-31','...','F','25000','333445555',5);

INSERT INTO empregado VALUES ('Ahmad','V','Jabbar','987987987','1969-03-29','...','M','25000','987654321',4);

INSERT INTO empregado VALUES ('James','E','Borg','888665555','1937-11-10','...','M','55000','',1);







