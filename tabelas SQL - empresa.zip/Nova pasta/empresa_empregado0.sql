-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: empresa
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empregado`
--

DROP TABLE IF EXISTS `empregado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empregado` (
  `FNAME` varchar(15) NOT NULL,
  `MINIT` char(1) DEFAULT NULL,
  `LNAME` varchar(15) NOT NULL,
  `SSN` char(9) NOT NULL,
  `BDATE` date DEFAULT NULL,
  `ADDRESS` varchar(30) DEFAULT NULL,
  `SEX` char(1) DEFAULT NULL,
  `SALARY` decimal(10,2) DEFAULT NULL,
  `SUPERSSN` char(9) DEFAULT NULL,
  `DNO` int(11) NOT NULL,
  PRIMARY KEY (`SSN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empregado`
--

LOCK TABLES `empregado` WRITE;
/*!40000 ALTER TABLE `empregado` DISABLE KEYS */;
INSERT INTO `empregado` VALUES ('John','B','Smith','123456789','1965-01-09','...','M',30000.00,'333445555',5),('Franklin','T','Wong','333445555','1955-12-08','...','M',40000.00,'888665555',5),('Alicia','J','Zelaya','999887777','1968-07-19','...','F',250000.00,'987654321',4),('Jennifer','S','Wallace','987654321','1941-06-20','...','F',43000.00,'888665555',4),('Ramesh','K','Narayan','666884444','1962-09-15','...','M',38000.00,'333445555',5),('Joyce','A','English','453453453','1972-07-31','...','F',25000.00,'333445555',5),('Ahmad','V','Jabbar','987987987','1969-03-29','...','M',25000.00,'987654321',4),('James','E','Borg','888665555','1937-11-10','...','M',55000.00,'',1);
/*!40000 ALTER TABLE `empregado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-10 11:34:28
