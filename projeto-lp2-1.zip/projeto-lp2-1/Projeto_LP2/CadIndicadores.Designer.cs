﻿namespace Projeto_LP2
{
    partial class CadIndicadores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadIndicadores));
            this.lbl_CodigoCadIndicadores = new System.Windows.Forms.Label();
            this.txt_CodigoCadIndicadores = new System.Windows.Forms.TextBox();
            this.txt_NomeCadIndicadores = new System.Windows.Forms.TextBox();
            this.lbl_NomeCadIndicadores = new System.Windows.Forms.Label();
            this.txt_DescricaoCadIndicadores = new System.Windows.Forms.TextBox();
            this.lbl_DescricaoCadIndicadores = new System.Windows.Forms.Label();
            this.txt_ObsCadIndicadores = new System.Windows.Forms.TextBox();
            this.lbl_ObsCadIndicadores = new System.Windows.Forms.Label();
            this.btn_OKCadIndicadores = new System.Windows.Forms.Button();
            this.btn_CancelarCadIndicadores = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CodigoCadIndicadores
            // 
            this.lbl_CodigoCadIndicadores.AutoSize = true;
            this.lbl_CodigoCadIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CodigoCadIndicadores.Location = new System.Drawing.Point(32, 19);
            this.lbl_CodigoCadIndicadores.Name = "lbl_CodigoCadIndicadores";
            this.lbl_CodigoCadIndicadores.Size = new System.Drawing.Size(56, 18);
            this.lbl_CodigoCadIndicadores.TabIndex = 0;
            this.lbl_CodigoCadIndicadores.Text = "Código";
            this.lbl_CodigoCadIndicadores.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_CodigoCadIndicadores
            // 
            this.txt_CodigoCadIndicadores.Location = new System.Drawing.Point(33, 40);
            this.txt_CodigoCadIndicadores.Name = "txt_CodigoCadIndicadores";
            this.txt_CodigoCadIndicadores.Size = new System.Drawing.Size(255, 20);
            this.txt_CodigoCadIndicadores.TabIndex = 1;
            this.txt_CodigoCadIndicadores.TextChanged += new System.EventHandler(this.txt_CodigoCadIndicadores_TextChanged);
            // 
            // txt_NomeCadIndicadores
            // 
            this.txt_NomeCadIndicadores.Location = new System.Drawing.Point(33, 94);
            this.txt_NomeCadIndicadores.Name = "txt_NomeCadIndicadores";
            this.txt_NomeCadIndicadores.Size = new System.Drawing.Size(255, 20);
            this.txt_NomeCadIndicadores.TabIndex = 3;
            this.txt_NomeCadIndicadores.TextChanged += new System.EventHandler(this.txt_NomeCadIndicadores_TextChanged);
            // 
            // lbl_NomeCadIndicadores
            // 
            this.lbl_NomeCadIndicadores.AutoSize = true;
            this.lbl_NomeCadIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NomeCadIndicadores.Location = new System.Drawing.Point(30, 73);
            this.lbl_NomeCadIndicadores.Name = "lbl_NomeCadIndicadores";
            this.lbl_NomeCadIndicadores.Size = new System.Drawing.Size(49, 18);
            this.lbl_NomeCadIndicadores.TabIndex = 2;
            this.lbl_NomeCadIndicadores.Text = "Nome";
            this.lbl_NomeCadIndicadores.Click += new System.EventHandler(this.lbl_NomeCadIndicadores_Click);
            // 
            // txt_DescricaoCadIndicadores
            // 
            this.txt_DescricaoCadIndicadores.Location = new System.Drawing.Point(33, 151);
            this.txt_DescricaoCadIndicadores.Multiline = true;
            this.txt_DescricaoCadIndicadores.Name = "txt_DescricaoCadIndicadores";
            this.txt_DescricaoCadIndicadores.Size = new System.Drawing.Size(255, 81);
            this.txt_DescricaoCadIndicadores.TabIndex = 5;
            this.txt_DescricaoCadIndicadores.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lbl_DescricaoCadIndicadores
            // 
            this.lbl_DescricaoCadIndicadores.AutoSize = true;
            this.lbl_DescricaoCadIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DescricaoCadIndicadores.Location = new System.Drawing.Point(30, 130);
            this.lbl_DescricaoCadIndicadores.Name = "lbl_DescricaoCadIndicadores";
            this.lbl_DescricaoCadIndicadores.Size = new System.Drawing.Size(76, 18);
            this.lbl_DescricaoCadIndicadores.TabIndex = 4;
            this.lbl_DescricaoCadIndicadores.Text = "Descrição";
            this.lbl_DescricaoCadIndicadores.Click += new System.EventHandler(this.lbl_DescricaoCadIndicadores_Click);
            // 
            // txt_ObsCadIndicadores
            // 
            this.txt_ObsCadIndicadores.Location = new System.Drawing.Point(35, 265);
            this.txt_ObsCadIndicadores.Multiline = true;
            this.txt_ObsCadIndicadores.Name = "txt_ObsCadIndicadores";
            this.txt_ObsCadIndicadores.Size = new System.Drawing.Size(253, 88);
            this.txt_ObsCadIndicadores.TabIndex = 7;
            this.txt_ObsCadIndicadores.TextChanged += new System.EventHandler(this.txt_ObsCadIndicadores_TextChanged);
            // 
            // lbl_ObsCadIndicadores
            // 
            this.lbl_ObsCadIndicadores.AutoSize = true;
            this.lbl_ObsCadIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ObsCadIndicadores.Location = new System.Drawing.Point(32, 244);
            this.lbl_ObsCadIndicadores.Name = "lbl_ObsCadIndicadores";
            this.lbl_ObsCadIndicadores.Size = new System.Drawing.Size(89, 18);
            this.lbl_ObsCadIndicadores.TabIndex = 6;
            this.lbl_ObsCadIndicadores.Text = "Observação";
            this.lbl_ObsCadIndicadores.Click += new System.EventHandler(this.lbl_ObsCadIndicadores_Click);
            // 
            // btn_OKCadIndicadores
            // 
            this.btn_OKCadIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OKCadIndicadores.Location = new System.Drawing.Point(38, 381);
            this.btn_OKCadIndicadores.Name = "btn_OKCadIndicadores";
            this.btn_OKCadIndicadores.Size = new System.Drawing.Size(105, 33);
            this.btn_OKCadIndicadores.TabIndex = 8;
            this.btn_OKCadIndicadores.Text = "Ok";
            this.btn_OKCadIndicadores.UseVisualStyleBackColor = true;
            this.btn_OKCadIndicadores.Click += new System.EventHandler(this.btn_OKCadIndicadores_Click);
            // 
            // btn_CancelarCadIndicadores
            // 
            this.btn_CancelarCadIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarCadIndicadores.Location = new System.Drawing.Point(183, 381);
            this.btn_CancelarCadIndicadores.Name = "btn_CancelarCadIndicadores";
            this.btn_CancelarCadIndicadores.Size = new System.Drawing.Size(105, 33);
            this.btn_CancelarCadIndicadores.TabIndex = 9;
            this.btn_CancelarCadIndicadores.Text = "Cancelar";
            this.btn_CancelarCadIndicadores.UseVisualStyleBackColor = true;
            this.btn_CancelarCadIndicadores.Click += new System.EventHandler(this.btn_CancelarCadIndicadores_Click);
            // 
            // CadIndicadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 429);
            this.Controls.Add(this.btn_CancelarCadIndicadores);
            this.Controls.Add(this.btn_OKCadIndicadores);
            this.Controls.Add(this.txt_ObsCadIndicadores);
            this.Controls.Add(this.lbl_ObsCadIndicadores);
            this.Controls.Add(this.txt_DescricaoCadIndicadores);
            this.Controls.Add(this.lbl_DescricaoCadIndicadores);
            this.Controls.Add(this.txt_NomeCadIndicadores);
            this.Controls.Add(this.lbl_NomeCadIndicadores);
            this.Controls.Add(this.txt_CodigoCadIndicadores);
            this.Controls.Add(this.lbl_CodigoCadIndicadores);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CadIndicadores";
            this.Text = "Cadastro de Indicador";
            this.Load += new System.EventHandler(this.CadIndicadores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CodigoCadIndicadores;
        private System.Windows.Forms.TextBox txt_CodigoCadIndicadores;
        private System.Windows.Forms.TextBox txt_NomeCadIndicadores;
        private System.Windows.Forms.Label lbl_NomeCadIndicadores;
        private System.Windows.Forms.TextBox txt_DescricaoCadIndicadores;
        private System.Windows.Forms.Label lbl_DescricaoCadIndicadores;
        private System.Windows.Forms.TextBox txt_ObsCadIndicadores;
        private System.Windows.Forms.Label lbl_ObsCadIndicadores;
        private System.Windows.Forms.Button btn_OKCadIndicadores;
        private System.Windows.Forms.Button btn_CancelarCadIndicadores;
    }
}