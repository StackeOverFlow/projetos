﻿namespace Projeto_LP2
{
    partial class EditarItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CadItemIndicadores = new System.Windows.Forms.Label();
            this.cmb_ItemIndicadores = new System.Windows.Forms.ComboBox();
            this.lbl_CadCodigoItemIndicadores = new System.Windows.Forms.Label();
            this.txt_CodigoCadItemIndicadores = new System.Windows.Forms.TextBox();
            this.lbl_NomeCadItemIndicadores = new System.Windows.Forms.Label();
            this.txt_NomeCadItemIndicadores = new System.Windows.Forms.TextBox();
            this.lbl_DescricaoCadItemIndicadores = new System.Windows.Forms.Label();
            this.txt_DescricaoCadItemIndicadores = new System.Windows.Forms.TextBox();
            this.lbl_ObsCadItemIndicadores = new System.Windows.Forms.Label();
            this.txt_ObsCadItemIndicadores = new System.Windows.Forms.TextBox();
            this.btn_OKCadItemIndicadores = new System.Windows.Forms.Button();
            this.btn_CancelarCadItemIndicadores = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CadItemIndicadores
            // 
            this.lbl_CadItemIndicadores.AutoSize = true;
            this.lbl_CadItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CadItemIndicadores.Location = new System.Drawing.Point(28, 18);
            this.lbl_CadItemIndicadores.Name = "lbl_CadItemIndicadores";
            this.lbl_CadItemIndicadores.Size = new System.Drawing.Size(37, 18);
            this.lbl_CadItemIndicadores.TabIndex = 22;
            this.lbl_CadItemIndicadores.Text = "Tipo";
            // 
            // cmb_ItemIndicadores
            // 
            this.cmb_ItemIndicadores.FormattingEnabled = true;
            this.cmb_ItemIndicadores.Location = new System.Drawing.Point(31, 39);
            this.cmb_ItemIndicadores.Name = "cmb_ItemIndicadores";
            this.cmb_ItemIndicadores.Size = new System.Drawing.Size(100, 21);
            this.cmb_ItemIndicadores.TabIndex = 23;
            // 
            // lbl_CadCodigoItemIndicadores
            // 
            this.lbl_CadCodigoItemIndicadores.AutoSize = true;
            this.lbl_CadCodigoItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CadCodigoItemIndicadores.Location = new System.Drawing.Point(188, 18);
            this.lbl_CadCodigoItemIndicadores.Name = "lbl_CadCodigoItemIndicadores";
            this.lbl_CadCodigoItemIndicadores.Size = new System.Drawing.Size(56, 18);
            this.lbl_CadCodigoItemIndicadores.TabIndex = 24;
            this.lbl_CadCodigoItemIndicadores.Text = "Código";
            // 
            // txt_CodigoCadItemIndicadores
            // 
            this.txt_CodigoCadItemIndicadores.Location = new System.Drawing.Point(179, 40);
            this.txt_CodigoCadItemIndicadores.Name = "txt_CodigoCadItemIndicadores";
            this.txt_CodigoCadItemIndicadores.Size = new System.Drawing.Size(100, 20);
            this.txt_CodigoCadItemIndicadores.TabIndex = 25;
            // 
            // lbl_NomeCadItemIndicadores
            // 
            this.lbl_NomeCadItemIndicadores.AutoSize = true;
            this.lbl_NomeCadItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NomeCadItemIndicadores.Location = new System.Drawing.Point(28, 75);
            this.lbl_NomeCadItemIndicadores.Name = "lbl_NomeCadItemIndicadores";
            this.lbl_NomeCadItemIndicadores.Size = new System.Drawing.Size(49, 18);
            this.lbl_NomeCadItemIndicadores.TabIndex = 26;
            this.lbl_NomeCadItemIndicadores.Text = "Nome";
            // 
            // txt_NomeCadItemIndicadores
            // 
            this.txt_NomeCadItemIndicadores.Location = new System.Drawing.Point(31, 96);
            this.txt_NomeCadItemIndicadores.Name = "txt_NomeCadItemIndicadores";
            this.txt_NomeCadItemIndicadores.Size = new System.Drawing.Size(248, 20);
            this.txt_NomeCadItemIndicadores.TabIndex = 27;
            // 
            // lbl_DescricaoCadItemIndicadores
            // 
            this.lbl_DescricaoCadItemIndicadores.AutoSize = true;
            this.lbl_DescricaoCadItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DescricaoCadItemIndicadores.Location = new System.Drawing.Point(28, 128);
            this.lbl_DescricaoCadItemIndicadores.Name = "lbl_DescricaoCadItemIndicadores";
            this.lbl_DescricaoCadItemIndicadores.Size = new System.Drawing.Size(76, 18);
            this.lbl_DescricaoCadItemIndicadores.TabIndex = 28;
            this.lbl_DescricaoCadItemIndicadores.Text = "Descrição";
            // 
            // txt_DescricaoCadItemIndicadores
            // 
            this.txt_DescricaoCadItemIndicadores.Location = new System.Drawing.Point(30, 149);
            this.txt_DescricaoCadItemIndicadores.Multiline = true;
            this.txt_DescricaoCadItemIndicadores.Name = "txt_DescricaoCadItemIndicadores";
            this.txt_DescricaoCadItemIndicadores.Size = new System.Drawing.Size(249, 81);
            this.txt_DescricaoCadItemIndicadores.TabIndex = 29;
            // 
            // lbl_ObsCadItemIndicadores
            // 
            this.lbl_ObsCadItemIndicadores.AutoSize = true;
            this.lbl_ObsCadItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ObsCadItemIndicadores.Location = new System.Drawing.Point(27, 242);
            this.lbl_ObsCadItemIndicadores.Name = "lbl_ObsCadItemIndicadores";
            this.lbl_ObsCadItemIndicadores.Size = new System.Drawing.Size(89, 18);
            this.lbl_ObsCadItemIndicadores.TabIndex = 30;
            this.lbl_ObsCadItemIndicadores.Text = "Observação";
            // 
            // txt_ObsCadItemIndicadores
            // 
            this.txt_ObsCadItemIndicadores.Location = new System.Drawing.Point(30, 263);
            this.txt_ObsCadItemIndicadores.Multiline = true;
            this.txt_ObsCadItemIndicadores.Name = "txt_ObsCadItemIndicadores";
            this.txt_ObsCadItemIndicadores.Size = new System.Drawing.Size(249, 88);
            this.txt_ObsCadItemIndicadores.TabIndex = 31;
            // 
            // btn_OKCadItemIndicadores
            // 
            this.btn_OKCadItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OKCadItemIndicadores.Location = new System.Drawing.Point(26, 384);
            this.btn_OKCadItemIndicadores.Name = "btn_OKCadItemIndicadores";
            this.btn_OKCadItemIndicadores.Size = new System.Drawing.Size(105, 33);
            this.btn_OKCadItemIndicadores.TabIndex = 32;
            this.btn_OKCadItemIndicadores.Text = "Ok";
            this.btn_OKCadItemIndicadores.UseVisualStyleBackColor = true;
            // 
            // btn_CancelarCadItemIndicadores
            // 
            this.btn_CancelarCadItemIndicadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarCadItemIndicadores.Location = new System.Drawing.Point(174, 384);
            this.btn_CancelarCadItemIndicadores.Name = "btn_CancelarCadItemIndicadores";
            this.btn_CancelarCadItemIndicadores.Size = new System.Drawing.Size(105, 33);
            this.btn_CancelarCadItemIndicadores.TabIndex = 33;
            this.btn_CancelarCadItemIndicadores.Text = "Cancelar";
            this.btn_CancelarCadItemIndicadores.UseVisualStyleBackColor = true;
            this.btn_CancelarCadItemIndicadores.Click += new System.EventHandler(this.btn_CancelarCadItemIndicadores_Click);
            // 
            // EditarItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 429);
            this.Controls.Add(this.btn_CancelarCadItemIndicadores);
            this.Controls.Add(this.btn_OKCadItemIndicadores);
            this.Controls.Add(this.txt_ObsCadItemIndicadores);
            this.Controls.Add(this.lbl_ObsCadItemIndicadores);
            this.Controls.Add(this.txt_DescricaoCadItemIndicadores);
            this.Controls.Add(this.lbl_DescricaoCadItemIndicadores);
            this.Controls.Add(this.txt_NomeCadItemIndicadores);
            this.Controls.Add(this.lbl_NomeCadItemIndicadores);
            this.Controls.Add(this.txt_CodigoCadItemIndicadores);
            this.Controls.Add(this.lbl_CadCodigoItemIndicadores);
            this.Controls.Add(this.cmb_ItemIndicadores);
            this.Controls.Add(this.lbl_CadItemIndicadores);
            this.Name = "EditarItem";
            this.Text = "EditarItem";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CadItemIndicadores;
        private System.Windows.Forms.ComboBox cmb_ItemIndicadores;
        private System.Windows.Forms.Label lbl_CadCodigoItemIndicadores;
        private System.Windows.Forms.TextBox txt_CodigoCadItemIndicadores;
        private System.Windows.Forms.Label lbl_NomeCadItemIndicadores;
        private System.Windows.Forms.TextBox txt_NomeCadItemIndicadores;
        private System.Windows.Forms.Label lbl_DescricaoCadItemIndicadores;
        private System.Windows.Forms.TextBox txt_DescricaoCadItemIndicadores;
        private System.Windows.Forms.Label lbl_ObsCadItemIndicadores;
        private System.Windows.Forms.TextBox txt_ObsCadItemIndicadores;
        private System.Windows.Forms.Button btn_OKCadItemIndicadores;
        private System.Windows.Forms.Button btn_CancelarCadItemIndicadores;
    }
}