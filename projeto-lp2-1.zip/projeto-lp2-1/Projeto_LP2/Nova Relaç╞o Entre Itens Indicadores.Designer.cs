﻿namespace Projeto_LP2
{
    partial class Nova_Relação_Entre_Itens_Indicadores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nova_Relação_Entre_Itens_Indicadores));
            this.cmb_DesafioNovaRel = new System.Windows.Forms.ComboBox();
            this.cmb_PropriedadeNovaRel = new System.Windows.Forms.ComboBox();
            this.lstView_DesafiosNovaRel = new System.Windows.Forms.ListView();
            this.lstView_PropriedadeNovaRel = new System.Windows.Forms.ListView();
            this.txt_JustificativNovaRel = new System.Windows.Forms.TextBox();
            this.lbl_NovaRel = new System.Windows.Forms.Label();
            this.btn_CancelarNovaRel = new System.Windows.Forms.Button();
            this.btn_AdicionarNovaRel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmb_DesafioNovaRel
            // 
            this.cmb_DesafioNovaRel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_DesafioNovaRel.FormattingEnabled = true;
            this.cmb_DesafioNovaRel.Location = new System.Drawing.Point(248, 12);
            this.cmb_DesafioNovaRel.Name = "cmb_DesafioNovaRel";
            this.cmb_DesafioNovaRel.Size = new System.Drawing.Size(202, 26);
            this.cmb_DesafioNovaRel.TabIndex = 0;
            this.cmb_DesafioNovaRel.Text = "DESAFIOS";
            // 
            // cmb_PropriedadeNovaRel
            // 
            this.cmb_PropriedadeNovaRel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_PropriedadeNovaRel.FormattingEnabled = true;
            this.cmb_PropriedadeNovaRel.Location = new System.Drawing.Point(12, 12);
            this.cmb_PropriedadeNovaRel.Name = "cmb_PropriedadeNovaRel";
            this.cmb_PropriedadeNovaRel.Size = new System.Drawing.Size(202, 26);
            this.cmb_PropriedadeNovaRel.TabIndex = 1;
            this.cmb_PropriedadeNovaRel.Text = "PROPRIEDADES";
            // 
            // lstView_DesafiosNovaRel
            // 
            this.lstView_DesafiosNovaRel.GridLines = true;
            this.lstView_DesafiosNovaRel.Location = new System.Drawing.Point(248, 55);
            this.lstView_DesafiosNovaRel.Name = "lstView_DesafiosNovaRel";
            this.lstView_DesafiosNovaRel.Size = new System.Drawing.Size(202, 131);
            this.lstView_DesafiosNovaRel.TabIndex = 3;
            this.lstView_DesafiosNovaRel.UseCompatibleStateImageBehavior = false;
            this.lstView_DesafiosNovaRel.View = System.Windows.Forms.View.Details;
            this.lstView_DesafiosNovaRel.SelectedIndexChanged += new System.EventHandler(this.lstView_DesafiosNovaRel_SelectedIndexChanged);
            // 
            // lstView_PropriedadeNovaRel
            // 
            this.lstView_PropriedadeNovaRel.GridLines = true;
            this.lstView_PropriedadeNovaRel.Location = new System.Drawing.Point(12, 55);
            this.lstView_PropriedadeNovaRel.Name = "lstView_PropriedadeNovaRel";
            this.lstView_PropriedadeNovaRel.Size = new System.Drawing.Size(202, 131);
            this.lstView_PropriedadeNovaRel.TabIndex = 3;
            this.lstView_PropriedadeNovaRel.UseCompatibleStateImageBehavior = false;
            this.lstView_PropriedadeNovaRel.View = System.Windows.Forms.View.Details;
            // 
            // txt_JustificativNovaRel
            // 
            this.txt_JustificativNovaRel.Location = new System.Drawing.Point(12, 225);
            this.txt_JustificativNovaRel.Multiline = true;
            this.txt_JustificativNovaRel.Name = "txt_JustificativNovaRel";
            this.txt_JustificativNovaRel.Size = new System.Drawing.Size(438, 81);
            this.txt_JustificativNovaRel.TabIndex = 4;
            // 
            // lbl_NovaRel
            // 
            this.lbl_NovaRel.AutoSize = true;
            this.lbl_NovaRel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NovaRel.Location = new System.Drawing.Point(12, 204);
            this.lbl_NovaRel.Name = "lbl_NovaRel";
            this.lbl_NovaRel.Size = new System.Drawing.Size(84, 18);
            this.lbl_NovaRel.TabIndex = 5;
            this.lbl_NovaRel.Text = "Justificativa";
            // 
            // btn_CancelarNovaRel
            // 
            this.btn_CancelarNovaRel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarNovaRel.Location = new System.Drawing.Point(248, 324);
            this.btn_CancelarNovaRel.Name = "btn_CancelarNovaRel";
            this.btn_CancelarNovaRel.Size = new System.Drawing.Size(160, 33);
            this.btn_CancelarNovaRel.TabIndex = 9;
            this.btn_CancelarNovaRel.Text = "Cancelar";
            this.btn_CancelarNovaRel.UseVisualStyleBackColor = true;
            // 
            // btn_AdicionarNovaRel
            // 
            this.btn_AdicionarNovaRel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AdicionarNovaRel.Location = new System.Drawing.Point(56, 324);
            this.btn_AdicionarNovaRel.Name = "btn_AdicionarNovaRel";
            this.btn_AdicionarNovaRel.Size = new System.Drawing.Size(158, 33);
            this.btn_AdicionarNovaRel.TabIndex = 8;
            this.btn_AdicionarNovaRel.Text = "Adicionar";
            this.btn_AdicionarNovaRel.UseVisualStyleBackColor = true;
            // 
            // Nova_Relação_Entre_Itens_Indicadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 369);
            this.Controls.Add(this.btn_CancelarNovaRel);
            this.Controls.Add(this.btn_AdicionarNovaRel);
            this.Controls.Add(this.lbl_NovaRel);
            this.Controls.Add(this.txt_JustificativNovaRel);
            this.Controls.Add(this.lstView_PropriedadeNovaRel);
            this.Controls.Add(this.lstView_DesafiosNovaRel);
            this.Controls.Add(this.cmb_PropriedadeNovaRel);
            this.Controls.Add(this.cmb_DesafioNovaRel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Nova_Relação_Entre_Itens_Indicadores";
            this.Text = "Nova Relação Entre Itens Indicadores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_DesafioNovaRel;
        private System.Windows.Forms.ComboBox cmb_PropriedadeNovaRel;
        private System.Windows.Forms.ListView lstView_DesafiosNovaRel;
        private System.Windows.Forms.ListView lstView_PropriedadeNovaRel;
        private System.Windows.Forms.TextBox txt_JustificativNovaRel;
        private System.Windows.Forms.Label lbl_NovaRel;
        private System.Windows.Forms.Button btn_CancelarNovaRel;
        private System.Windows.Forms.Button btn_AdicionarNovaRel;
    }
}