﻿namespace Projeto_LP2
{
    partial class Nova_Relação_Entre_Indicadores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nova_Relação_Entre_Indicadores));
            this.lbl_Indi1NovaRelIndi = new System.Windows.Forms.Label();
            this.lbl_Indi2NovaRelIndi = new System.Windows.Forms.Label();
            this.cmb_Indi1NovaRelIndi = new System.Windows.Forms.ComboBox();
            this.cmb_Indi2NovaRelIndi = new System.Windows.Forms.ComboBox();
            this.txt_JustificativaNovaRelIndi = new System.Windows.Forms.TextBox();
            this.lbl_JustificativaNovaRelIndi = new System.Windows.Forms.Label();
            this.btn_CancelarNovaRelIndi = new System.Windows.Forms.Button();
            this.btn_OKNovaRelIndi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Indi1NovaRelIndi
            // 
            this.lbl_Indi1NovaRelIndi.AutoSize = true;
            this.lbl_Indi1NovaRelIndi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Indi1NovaRelIndi.Location = new System.Drawing.Point(12, 13);
            this.lbl_Indi1NovaRelIndi.Name = "lbl_Indi1NovaRelIndi";
            this.lbl_Indi1NovaRelIndi.Size = new System.Drawing.Size(80, 18);
            this.lbl_Indi1NovaRelIndi.TabIndex = 0;
            this.lbl_Indi1NovaRelIndi.Text = "Indicador 1";
            // 
            // lbl_Indi2NovaRelIndi
            // 
            this.lbl_Indi2NovaRelIndi.AutoSize = true;
            this.lbl_Indi2NovaRelIndi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Indi2NovaRelIndi.Location = new System.Drawing.Point(218, 13);
            this.lbl_Indi2NovaRelIndi.Name = "lbl_Indi2NovaRelIndi";
            this.lbl_Indi2NovaRelIndi.Size = new System.Drawing.Size(80, 18);
            this.lbl_Indi2NovaRelIndi.TabIndex = 1;
            this.lbl_Indi2NovaRelIndi.Text = "Indicador 2";
            // 
            // cmb_Indi1NovaRelIndi
            // 
            this.cmb_Indi1NovaRelIndi.FormattingEnabled = true;
            this.cmb_Indi1NovaRelIndi.Location = new System.Drawing.Point(15, 34);
            this.cmb_Indi1NovaRelIndi.Name = "cmb_Indi1NovaRelIndi";
            this.cmb_Indi1NovaRelIndi.Size = new System.Drawing.Size(170, 21);
            this.cmb_Indi1NovaRelIndi.TabIndex = 2;
            // 
            // cmb_Indi2NovaRelIndi
            // 
            this.cmb_Indi2NovaRelIndi.FormattingEnabled = true;
            this.cmb_Indi2NovaRelIndi.Location = new System.Drawing.Point(221, 34);
            this.cmb_Indi2NovaRelIndi.Name = "cmb_Indi2NovaRelIndi";
            this.cmb_Indi2NovaRelIndi.Size = new System.Drawing.Size(170, 21);
            this.cmb_Indi2NovaRelIndi.TabIndex = 3;
            // 
            // txt_JustificativaNovaRelIndi
            // 
            this.txt_JustificativaNovaRelIndi.Location = new System.Drawing.Point(15, 98);
            this.txt_JustificativaNovaRelIndi.Multiline = true;
            this.txt_JustificativaNovaRelIndi.Name = "txt_JustificativaNovaRelIndi";
            this.txt_JustificativaNovaRelIndi.Size = new System.Drawing.Size(376, 161);
            this.txt_JustificativaNovaRelIndi.TabIndex = 4;
            // 
            // lbl_JustificativaNovaRelIndi
            // 
            this.lbl_JustificativaNovaRelIndi.AutoSize = true;
            this.lbl_JustificativaNovaRelIndi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_JustificativaNovaRelIndi.Location = new System.Drawing.Point(12, 77);
            this.lbl_JustificativaNovaRelIndi.Name = "lbl_JustificativaNovaRelIndi";
            this.lbl_JustificativaNovaRelIndi.Size = new System.Drawing.Size(84, 18);
            this.lbl_JustificativaNovaRelIndi.TabIndex = 5;
            this.lbl_JustificativaNovaRelIndi.Text = "Justificativa";
            // 
            // btn_CancelarNovaRelIndi
            // 
            this.btn_CancelarNovaRelIndi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelarNovaRelIndi.Location = new System.Drawing.Point(221, 280);
            this.btn_CancelarNovaRelIndi.Name = "btn_CancelarNovaRelIndi";
            this.btn_CancelarNovaRelIndi.Size = new System.Drawing.Size(160, 33);
            this.btn_CancelarNovaRelIndi.TabIndex = 11;
            this.btn_CancelarNovaRelIndi.Text = "Cancelar";
            this.btn_CancelarNovaRelIndi.UseVisualStyleBackColor = true;
            this.btn_CancelarNovaRelIndi.Click += new System.EventHandler(this.btn_CancelarNovaRelIndi_Click);
            // 
            // btn_OKNovaRelIndi
            // 
            this.btn_OKNovaRelIndi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OKNovaRelIndi.Location = new System.Drawing.Point(27, 280);
            this.btn_OKNovaRelIndi.Name = "btn_OKNovaRelIndi";
            this.btn_OKNovaRelIndi.Size = new System.Drawing.Size(158, 33);
            this.btn_OKNovaRelIndi.TabIndex = 10;
            this.btn_OKNovaRelIndi.Text = "Ok";
            this.btn_OKNovaRelIndi.UseVisualStyleBackColor = true;
            this.btn_OKNovaRelIndi.Click += new System.EventHandler(this.btn_OKNovaRelIndi_Click);
            // 
            // Nova_Relação_Entre_Indicadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 329);
            this.Controls.Add(this.btn_CancelarNovaRelIndi);
            this.Controls.Add(this.btn_OKNovaRelIndi);
            this.Controls.Add(this.lbl_JustificativaNovaRelIndi);
            this.Controls.Add(this.txt_JustificativaNovaRelIndi);
            this.Controls.Add(this.cmb_Indi2NovaRelIndi);
            this.Controls.Add(this.cmb_Indi1NovaRelIndi);
            this.Controls.Add(this.lbl_Indi2NovaRelIndi);
            this.Controls.Add(this.lbl_Indi1NovaRelIndi);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Nova_Relação_Entre_Indicadores";
            this.Text = "Nova Relação Entre Indicadores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Indi1NovaRelIndi;
        private System.Windows.Forms.Label lbl_Indi2NovaRelIndi;
        private System.Windows.Forms.ComboBox cmb_Indi1NovaRelIndi;
        private System.Windows.Forms.ComboBox cmb_Indi2NovaRelIndi;
        private System.Windows.Forms.TextBox txt_JustificativaNovaRelIndi;
        private System.Windows.Forms.Label lbl_JustificativaNovaRelIndi;
        private System.Windows.Forms.Button btn_CancelarNovaRelIndi;
        private System.Windows.Forms.Button btn_OKNovaRelIndi;
    }
}