﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 *  sao vetores de caracteres, utilizamos em metodos o mais comun eh o "Console.WriteLine",
 *  onde podemos concatenar junto a uma ou varias strings
 */
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string cronica = "A vida é curta e na entrega ao medo perdemos um tempo precioso, o medo é igual a dor, salva, é um sinal que algo precisa ser feito, então tente, só assim saberá o que podia ter ganhado com aquilo, perder tenho certeza que nunca perderá nada arriscando, tudo na vida é um aprendizado, uma nova experiência, então tente!";

            cronica = cronica.ToLower();
            
            while(cronica.Length < 200)
            {
                Console.WriteLine("Digite uma cadeia maior que 200 caracteres!");
                cronica = Console.ReadLine();
            }

            string[] palavras = cronica.Split(' ');
            

            for (int x = 0; x < palavras.Length; x++)
            {
                if((palavras[x].StartsWith("p")) || (palavras[x].StartsWith("b")) || (palavras[x].StartsWith("m")))
                {
                    if(palavras[x].StartsWith("p"))
                    {
                        palavras[x] = palavras[x].Replace("p", "x");
                    }
                    else if (palavras[x].StartsWith("b"))
                    {
                        palavras[x] = palavras[x].Replace("b", "y");
                    }
                    else if (palavras[x].StartsWith("m"))
                    {
                        palavras[x] = palavras[x].Replace("m", "z");
                    }
                }

                if((palavras[x].EndsWith("m")) || (palavras[x].EndsWith("l")) || (palavras[x].EndsWith("a")))
                {
                    palavras[x] = "opa";
                }

                if(palavras[x].Length <= 3 )
                {
                    palavras[x] = palavras[x].ToUpper();
                }
            }

            cronica = string.Join(" ", palavras);
            Console.WriteLine(cronica);
            Console.ReadKey();
        }
    }
}
