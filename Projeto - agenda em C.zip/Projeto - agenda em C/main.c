#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <locale.h>
#include <stdbool.h>

//VARIAVEIS GLOBAIS
int cont1= 0, cont2=0, cont3=0;

void limpa_buffer(void){
    char c;
    while ((c= getchar())  != '\n' && c != EOF);

};

struct compromisso {

    int hora, minuto, Ahora, Aminuto, dia, mes, ano;
    char titulo [50], local[50], descricao[50];

};

struct compromisso cadastrar(struct compromisso x){


    system ("cls");
    printf("compromisso: %i\n", cont2 +1);
    printf("Digite o t�tulo do compromisso: ");
    limpa_buffer();
    fgets(x.titulo, 50, stdin);


    printf("\nDigite o Local:");
    fgets(x.local, 50, stdin);


    printf("\nDigite uma Descri��o do compromisso:");
    fgets(x.descricao, 50, stdin);

    do{
    printf("\nDigite a Hora(HH:MM):");
    scanf("%i:%i", &x.hora, &x.minuto);
    if((x.hora> 24) || (x.minuto > 59)){
        system("cls");
        printf("Erro!\nFormato da hora invalido.\nPor Favor,");
    }
    }while((x.hora> 24) || (x.minuto > 59));

    do{
    printf("\nDigite o hor�rio do alarme(HH:MM):");
    scanf("%i:%i", &x.Ahora, &x.Aminuto);
    if((x.Ahora> 24) || (x.Aminuto > 59)){
        system("cls");
        printf("Erro!\nFormato da hora invalido.\nPor Favor,");
    }
    }while((x.Ahora> 24) || (x.Aminuto > 59));

    printf("\nDigite a Data (dd/mm/aaaa):");
    scanf("%i/%i/%i", &x.dia, &x.mes, &x.ano);

    system("cls");

    return x;


};

void mostra_compromisso (struct compromisso depois) {

    printf("                                                            %i\n",cont3+1);
    printf("Nome:%s", depois.titulo);
    printf("\nLocal: %s",depois.local);
    printf("\nDescri��o: %s",depois.descricao);
    printf("\ndata: %i/%i/%i",depois.dia, depois.mes, depois.ano);
    printf("\n\nHora: %i:%i", depois.hora, depois.minuto);
    printf("\n\nAlarme: %i:%i", depois.Ahora, depois.Aminuto);
    printf ("\n-----------------------------------------------------------||---------------------------------------------\n\n");
}

bool stringsiguais(char s1 [], char s2 []){

    int i=0;

    while (s1[i] == s2[i] && s1[i]!= '\0' && s2[i]!= '\0'){

        i++;
    }
    if(s1[i]=='\0' && s2[i]=='\0'){
        return 1;
    } else {
        return 0;
    }
}

void comp_cadastrado  (struct compromisso x, struct compromisso y){

    if(stringsiguais(x.titulo, y.titulo)){

        if(x.hora == y.hora){

            if(x.minuto == y.minuto){

            if((x.dia == y.dia) && (x.mes == y.mes) && (x.ano == y.ano)){

                system ("cls");
                printf("Compromisso deletado.\nPois ja foi cadastrado!");
                cont2--;
                getch();

                }
            }
        }

    }

}

struct compromisso alterar_comp (struct compromisso x, int a){

    printf("\n\nVoce esta alterando o compromisso: %i\n\n",a);
    printf("Digite o t�tulo do compromisso: ");
    limpa_buffer();
    fgets(x.titulo, 50, stdin);

    printf("\nDigite o Local:");
    fgets(x.local, 50, stdin);

    printf("\nDigite uma Descri��o do compromisso:");
    fgets(x.descricao, 50, stdin);

    do{
    printf("\nDigite a Hora(HH:MM):");
    scanf("%i:%i", &x.hora, &x.minuto);
    if((x.hora> 24) || (x.minuto > 59)){
        system("cls");
        printf("Erro!\nFormato da hora invalido.\nPor Favor,");
    }
    }while((x.hora> 24) || (x.minuto > 59));

    do{
    printf("\nDigite o hor�rio do alarme(HH:MM):");
    scanf("%i:%i", &x.Ahora, &x.Aminuto);
    if((x.Ahora> 24) || (x.Aminuto > 59)){
        system("cls");
        printf("Erro!\nFormato da hora invalido.\nPor Favor,");
    }
    }while((x.Ahora> 24) || (x.Aminuto > 59));

    printf("\nDigite a Data (DD/MM/AAAA):");
    scanf("%i/%i/%i", &x.dia, &x.mes, &x.ano);

    system("cls");

    return x;
};

struct data_atual {

    int dia, mes, ano;
};

void compromisso_dia (struct data_atual x,struct compromisso y){


    if(x.ano == y.ano){
            if(x.mes == y.mes){
                if(x.dia == y.dia){
                    mostra_compromisso(y);

                }
            }
        }


}

void compromisso_semana (struct compromisso x, struct data_atual hoje){

    if((hoje.dia >= 1) && (hoje.dia <=7)){
        if((x.dia >= 1) && (x.dia <=7)){
            mostra_compromisso(x);
        }
    }else if((hoje.dia >= 8) && (hoje.dia <=14)){
            if((x.dia >= 8) && (x.dia <=14)){
            mostra_compromisso(x);
            }
    }else if((hoje.dia >= 15) && (hoje.dia <=21)){
              if((x.dia >= 15) && (x.dia <=21)){
                mostra_compromisso (x);
              }
            }else if((hoje.dia >= 22) && (hoje.dia <=28)){
                   if((x.dia >= 22) && (x.dia <=28)){
                     mostra_compromisso (x);
                    }
                }else if((hoje.dia >= 29) && (hoje.dia <=31)){
                   if((x.dia >= 29) && (x.dia <=31)){
                     mostra_compromisso (x);
                    }
                }
}



int main(){

    //HABILITA A UTILIZACAO DE ACENTOS
    setlocale (LC_ALL, "Portuguese");

    struct compromisso cadastrar(struct compromisso x);
    void mostra_compromisso (struct compromisso depois);
    bool stringsiguais(char s1 [], char s2 []);
    void comp_cadastrado  (struct compromisso x, struct compromisso y);
    struct compromisso alterar_comp (struct compromisso x, int a);
    void compromisso_dia (struct data_atual x, struct compromisso y);
    struct data_atual define_data(struct data_atual hoje);
    void compromisso_semana (struct compromisso x, struct data_atual hoje);

    int opcao, opcao2, a, cont4, w, x, y=0;
    char c;

    struct compromisso agora;
    struct compromisso *depois;
    struct data_atual hoje;

    depois = malloc (sizeof (struct compromisso));

//LEITURA DO ARQUIVO (SE ELE EXISTIR)

    FILE *agenda;
    agenda = fopen ("agenda.txt","rb");

    if (agenda == NULL){
        fclose(agenda);
    }else{
        while (!feof(agenda)){
        depois = realloc (depois,(cont2+1) * sizeof(struct compromisso));
        fread (&agora, sizeof(struct compromisso), 1, agenda);
        depois[cont2] = agora;
        cont2++;
        }
        fclose(agenda);
        cont2--;
    }

// DEFINE O DIA ATUAL
    do{
            system ("cls");
            printf("Digite a data atual (DD/MM/AAAA):");
            scanf ("%i/%i/%i", &hoje.dia, &hoje.mes, &hoje.ano);

            if((hoje.dia > 31) || (hoje.mes > 12)){
                system("cls");
                printf("Essa data n�o existe.");
                getch();
            }
        }while((hoje.dia > 31) || (hoje.mes > 12));



// MENU DE OP��ES
    system("cls");
    printf("                                                  Agenda!\n\n\n");
    printf("Menu de Op��es:\n\n");

    do{
        system("cls");
        printf("1. Cadastrar compromisso\n");
        printf("2. Buscar compromisso(s)\n");
        printf("3. Alterar compromisso\n");
        printf("4. Remover compromisso(s)\n");
        printf("5. Sair\n\n");

        scanf ("%d", &opcao);

        switch (opcao){

        case 1:

            depois = realloc (depois, (cont2+1) * sizeof(struct compromisso));
            depois[cont2] = cadastrar(agora);

            //verifica se o compromisso cadastrado ja existe

            if(cont2 == 0);
            else{
            for(cont3=(cont2-1); cont3>=0; cont3--){

                comp_cadastrado(depois[cont2], depois[cont3]);
              }
            }
            cont2++;
            break;

        case 2:

                system("cls");
                printf("Listar:\n\n");
                printf("1. Todos os compromissos\n");
                printf("2. Compromissos do dia\n");
                printf("3. Compromissos de uma semana\n");
                printf("4. Compromissos do m�s\n");
                printf("5. Compromissos em ordem cronol�gica\n");
                printf("6. Sair\n");


                scanf("%i", &opcao2);

                switch (opcao2){

                case 1:

                    system("cls");
                    printf ("Listagem de compromissos.\n");
                    printf ("-----------------------------------------------------------||---------------------------------------------\n");
                    for (cont3= 0; cont3<cont2; cont3++){

                        mostra_compromisso(depois[cont3]);
                    }
                    getch();
                    break;

                case 2:
                        system("cls");
                        for(cont4=0; cont4<cont2; cont4++){
                           compromisso_dia(hoje, depois[cont4]);
                        }
                       getch();

                    break;

                case 3:
                        a = 0;
                        system("cls");
                        printf("Data de hoje:%i/%i/%i \n", hoje.dia, hoje.mes, hoje.ano);
                        printf ("-----------------------------------------------------------||---------------------------------------------\n");
                        for (cont3= 0; cont3<cont2; cont3++){
                            if((hoje.mes == depois[cont3].mes) && (hoje.ano == depois[cont3].ano)){
                                compromisso_semana(depois[cont3], hoje);
                                a++;
                            }
                    }
                    if(a == 0){
                        printf("Voc� n�o tem nenhum compromisso essa semana");
                        printf("Data de hoje:%i/%i/%i \n", hoje.dia, hoje.mes, hoje.ano);

                    }
                    getch();
                    break;

                case 4:
                    a = 0;
                        system("cls");
                        printf("Data de hoje:%i/%i/%i \n", hoje.dia, hoje.mes, hoje.ano);
                        printf ("-----------------------------------------------------------||---------------------------------------------\n");
                        for(cont3 =0; cont3<cont2; cont3++){
                                if((hoje.mes == depois[cont3].mes) && (hoje.ano == depois[cont3].ano)){
                                    mostra_compromisso(depois[cont3]);
                                    a++;
                                }

                        }
                        if(a == 0){
                            printf("Voc� n�o tem nenhum compromisso esse m�s");
                        }
                        getch();
                    break;

                case 5:
                        system("cls");
                        printf("Data de hoje:%i/%i/%i \n", hoje.dia, hoje.mes, hoje.ano);
                        printf ("-----------------------------------------------------------||---------------------------------------------\n");
                        for(cont3=0;cont3<=cont2;cont3++){
                            for(w = 0; w<cont2; w++){
                                for(x=w+1; x<cont2; x++){
                                    if(depois[w].ano > depois[x].ano){
                                        agora = depois[w];
                                        depois[w] = depois[x];
                                        depois[x] = agora;
                                    }else if(depois[w].mes > depois[x].mes){
                                            agora = depois[w];
                                            depois[w] = depois[x];
                                            depois[x] = agora;
                                        }else if(depois[w].dia > depois[x].dia){
                                                agora = depois[w];
                                                depois[w] = depois[x];
                                                depois[x] = agora;
                                            }
                                }
                            }
                        }
                        cont3= 0;
                        for(w = 0; w<cont2; w++){

                            mostra_compromisso(depois[w]);
                            cont3++;
                        }
                        getch();
                        cont3 = 0;
                    break;

                case 6:
                    break;

                }

            break;


        case 3:
            system("cls");
            printf("Deseja listar todos os  compromisso? (s/n):");
            limpa_buffer();
            scanf("%c", &c);
            do{
                if (c == 's'){
                    system("cls");
                    printf ("Listagem de compromissos.\n");
                    printf ("-----------------------------------------------------------||---------------------------------------------\n");
                    for (cont3= 0; cont3<cont2; cont3++){

                        mostra_compromisso(depois[cont3]);
                    }
                }
                printf("qual o numero do compromisso que deseja alterar?:");
                scanf("%i", &a);
                if(a>cont2){
                    system("cls");
                    printf("Erro!\n");
                    printf("cadastro n�o existe.");
                    getch();
                }
            }while(a>cont2);

            printf("Certeza? (s/n):");
            limpa_buffer ();
            scanf("%c", &c);
            if (c == 's'){
            depois[a-1]= alterar_comp (depois[a-1], a);
            }
            break;
        case 4:

            system("cls");
            printf("Deseja listar todos os  compromisso? (s/n):  ");
            limpa_buffer();
            scanf("%c", &c);

                if (c == 's'){
                    system("cls");
                    printf ("Listagem de compromissos.\n");
                    printf ("-----------------------------------------------------------||---------------------------------------------\n");
                    for (cont3= 0; cont3<cont2; cont3++){

                        mostra_compromisso(depois[cont3]);
                    }
                }

                printf("Qual compromisso deseja remover?  ");
                    scanf("%i", &a);
                    printf("\n\nConfirmar? (s/n):");
                    limpa_buffer();
                    scanf("%c", &c);
                    if(c == 's'){
                        for(x=a;x<cont2;x++){
                            for(w=a;w<cont2;w++){
                                depois[x-1] = depois[w];

                            }
                }
                cont2--;
                    }

            break;

        default:
            agenda = fopen ("agenda.txt","wb");
            for(cont4 = 0; cont4<cont2; cont4++){
                agora = depois[cont4];
                fwrite(&agora, sizeof(struct compromisso), 1, agenda);
                y++;
            }
            if(y == cont2){
                system("cls");
                printf("Sucesso ao salvar compromissos.\n\n\n\n");
                getch();
            }else{
                system("cls");
                printf("Falha ao salvar compromissos.\n\n\n\n");
                getch();
            }
            fclose(agenda);
            break;

        }

    }while (opcao != 5);

    system ("cls");
    return 0;
}


