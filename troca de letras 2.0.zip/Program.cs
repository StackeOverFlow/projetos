﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            string cronica = "Mais que uma mão estendida, mais que um belo sorriso, mais do que a alegria de dividir, mais do que sonhar os mesmos sonhos ou doer as mesmas dores.";

            StreamWriter escritor = new StreamWriter("text.txt", false);
            escritor.WriteLine(cronica);
            escritor.Close();

            StreamReader leitor = new StreamReader("text.txt"); 
            cronica = leitor.ReadToEnd();
            leitor.Close();       
                

            char[] palavra;

            cronica = cronica.ToLower();                

            string[] palavras = cronica.Split(' ');


            for (int x = 0; x < palavras.Length; x++)
            {

                if ((palavras[x].StartsWith("p")) || (palavras[x].StartsWith("b")) || (palavras[x].StartsWith("m")))
                {

                    palavra = palavras[x].ToCharArray(0, palavras[x].Length);

                    for (int z = 0; z < palavra.Length; z++)
                    {

                            if (palavra[z] == 'a')
                            {
                                palavra[z] = 'x';
                            }
                            else if (palavra[z] == 'e')
                            {
                                palavra[z] = 'y';
                            }
                            else if (palavra[z] == 'i')
                            {
                                palavra[z] = 'z';
                            }
                            else if (palavra[z] == 'o')
                            {
                                palavra[z] = 'x';
                            }
                            else if (palavra[z] == 'u')
                            {
                                palavra[z] = 'y';
                            }

                    }
                        palavras[x] = string.Join("", palavra);
                }

                    if ((palavras[x].EndsWith("m")) || (palavras[x].EndsWith("l")) || (palavras[x].EndsWith("a")))
                    {
                        palavras[x] = "opa";
                    }

                    if (palavras[x].Length <= 3)
                    {
                        palavras[x] = palavras[x].ToUpper();
                    }
            }

                cronica = string.Join(" ", palavras);
                Console.WriteLine(cronica);
                Console.ReadKey();

            escritor = new StreamWriter("text.txt", false);
            escritor.WriteLine(cronica);
            escritor.Close();

        }
    }
}
