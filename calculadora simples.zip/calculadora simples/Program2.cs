﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string num1, num2;
            double num3, num4, resultado = 0;
            char x;

            Console.Write("Digite um numero:");
            num1 = Console.ReadLine();
            Console.Write("\nDigite outro numero:");
            num2 = Console.ReadLine();

            bool cond1 = Double.TryParse(num1, out num3);
            bool cond2 = Double.TryParse(num2, out num4);

            if (cond1 && cond2)
            {
                //
            }
            else
            {
                Console.WriteLine("Erro ao tentar converter os numeros!");
                Console.ReadKey();
                return;
            }
                     
            Console.WriteLine("\nInsira a operaçâo escolhida (+, -, x, /):");
            x = char.Parse(Console.ReadLine());
            
            if(x == '+')
            {
                resultado = num3 + num4;
            }
            else if (x == '-')
            {
                resultado = num3 - num4;
            }
            else if (x == 'x')
            {
                resultado = num3 * num4;
            }
            else if (x == '/')
            {
                resultado = num3 / num4;
            }

            num1 = string.Format("Resultado da operação de: {0:F} {1} {2:F} = {3:F}", num3, x, num4, resultado);
            Console.WriteLine(num1);
            Console.ReadKey();
        }
    }
}
