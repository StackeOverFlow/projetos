#include <stdio.h>
#include <stdlib.h>
#define N 10
//N= numero max de produtos

void limpa_buffer(void){
    char c;
    while ((c= getchar())  != '\n' && c != EOF);
}




struct produto
{
    int codigo, preco, quantidade;
    char nome[50];
};


union tipo_fornecedor
{
    short int cnpj, cpf;
};

//------------------------------------------------------------
int main()
{
    struct produto p[N];
    union tipo_fornecedor f[N];
    int v, w=0, x, y, z,opcao, cod2;




//MENU
for(x=0;x<=N;x++)
{
do{
        system("cls");

        printf("                    menu de opcoes\n");
        printf("\n 1.cadastrar produtos");
        printf("\n 2.vender produtos");
        printf("\n 3.comprar produtos");
        printf("\n 4.consultar produtos\n");

        scanf("%d",&opcao);



switch (opcao)
{

case 1://CADASTRAR PRODUTOS
    {
        system("cls");

        printf("digite o codigo do produto:");
        scanf("%d",&p[x].codigo);
        limpa_buffer();

        printf("\ndigite o preco do produto:");
        scanf("%d",&p[x].preco);
        limpa_buffer();

        printf("\ndigite o quantidade do produto:");
        scanf("%d",&p[x].quantidade);
        limpa_buffer();

        printf("\ndigite o nome do produto:");
        fgets(p[x].nome,50,stdin);

        printf("\ndigite o cpf ou o cnpj do fornecedor:");
        scanf("%d",&f[x]);
        limpa_buffer();

        system("cls");

        printf("        produto cadastrado com sucesso!\n");

        system("pause");

        system("cls");

        break;
    }

case 2://vENDER PRODUTOS
    {
        system("cls");

        limpa_buffer();
        printf("digite o codigo do produto:");
        scanf("%d",&cod2);

        system("cls");

        for(y=0;y<N;y++){ //verificando codigo
            if(cod2 != p[y].codigo)w++;
            if(cod2 == p[y].codigo){
                    printf("codigo do produto: %d",p[y].codigo);
                    printf("\npreco do produto: %d",p[y].preco);
                    printf("\nquantidade do produto: %d",p[y].quantidade);
                    printf("\nnome do produto: %s",p[y].nome);

                    printf("\n\n1.vender produto");
                    printf("\n2.cancela\n");
                    scanf("%d",&z);

                    if(z==1){
                        system("cls");
                        printf("quantas unidades?\n");
                        scanf("%d",&z);
                        p[y].quantidade=p[y].quantidade-z;

                        if(z>p[y].quantidade)printf("numero de produtos acima do estoque");
                        else{
                        system("cls");

                        printf("voce vendeu %d unidades de %s\n", z, p[y].nome);
                        printf("ainda restam %d unidades\n", p[y].quantidade);

                        system("pause");


                        }

                        }




                }

        }
        //mensagem de produto nao encontrado
                if(w==N){
                    printf("produto nao encontrado!!!");
                    system("pause");
                    system("cls");

        limpa_buffer();
        opcao=5;


        }
        break;

    }
case 3://comprar produtos
    {
        system("cls");

        printf("digite o codigo do produto:");
        scanf("%d",&cod2);
        system("cls");
        printf("digite o numero de itens comprados:");
        scanf("%d",&v);

         for(y=0;y<N;y++){ //verificando codigo
                if(cod2 == p[y].codigo){
                    p[y].quantidade = p[y].quantidade+v;

                    printf("total de %s no estoque: %d\n",p[y].nome, p[y].quantidade);

                    printf("\n1.SAIR\n");
                    system("cls");

                };

        }


    break;
    }

case 4://CONSULTAR PRODUTOS
    {


        system("cls");

        printf("1.consultar todos os produtos\n");
        printf("2.consultar um especifico\n");
        scanf("%d",&v);
        if(v==1){
                if(x=0)printf("nenhum produto cadastrado");
                else{
            for(v=0;v<=x;v++){
                    printf("codigo do produto: %d",p[v].codigo);
                    printf("\npreco do produto: %d",p[v].preco);
                    printf("\nquantidade do produto: %d",p[v].quantidade);
                    printf("\nnome do produto: %s\n",p[v].nome);
                    printf("-------------------------//-------------------------\n");
            }
            system("pause");
        }
        }
        else{
                if(v==2){
        limpa_buffer();
        printf("digite o codigo do produto:");
        scanf("%d",&cod2);

        system("cls");


    for(y=0;y<N;y++){ //verificando codigo
            if(cod2 != p[y].codigo)w++;
            if(cod2 == p[y].codigo){
                    printf("codigo do produto: %d",p[y].codigo);
                    printf("\npreco do produto: %d",p[y].preco);
                    printf("\nquantidade do produto: %d",p[y].quantidade);
                    printf("\nnome do produto: %s",p[y].nome);

                    printf("\n1.SAIR\n");
                    scanf("%d",&z);

                    system("cls");

                };

        }
        //mensagem de produto nao encontrado
                if(w==N){
                    printf("produto nao encontrado!!!\n\n");
                    limpa_buffer();
                    system("pause");
                    system("cls");
                    }
                }
            }
        }break;



default://ERRO
    {
        system("cls");

        printf("Erro!!!");

        system("pause");

        system("cls");

        break;
                    };


            }opcao=0;
        }while(opcao !=4);
}
    }






































































