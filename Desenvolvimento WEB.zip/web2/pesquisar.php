


<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>WEB2</title>
    <link rel="stylesheet" href="_css/estilo.css">
</head>
<body>
<div class ="container">
    <nav>
        <ul class="menu">
            <a href="index.php"><li>Cadastro</li></a>
            <a href="Consultas.php"><li>Consultas</li></a>
            <a href="Alteracao.php"><li>Alteracao</li></a>
            <a href="Exclusao.php"><li>Exclusão</li></a>

        </ul>
    </nav>
    <section>
        <h1>Consulta</h1>
        <hr><br><br>

        <?php


        $hostname = "localhost";
        $user = "root";
        $password = "";
        $database = "cadastro";
        $conexao = mysqli_connect($hostname, $user, $password, $database);


        $pesquisar = $_POST['pesquisar'];
        $result_cursos = "SELECT * FROM usuarios WHERE nome LIKE '%$pesquisar%' LIMIT 5";
        $resultado_cursos = mysqli_query($conexao, $result_cursos);

        while($rows_cursos = mysqli_fetch_array($resultado_cursos)){
            echo "descrição: ".$rows_cursos['nome']."<br>";
        }



        ?>


        </form>
    </section>
</div>
</body>
</html>
