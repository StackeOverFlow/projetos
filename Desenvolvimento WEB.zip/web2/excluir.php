<<?php

$hostname = "localhost";
$user= "root";
$password="";
$database= "cadastro";
$conexao= mysqli_connect($hostname, $user, $password, $database);

$descatual = $_POST['descatual'];

$result_DES = " DELETE FROM usuarios WHERE nome = '$descatual'";
$resultado_cursos = mysqli_query($conexao, $result_DES);




?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>WEB2</title>
    <link rel="stylesheet" href="_css/estilo.css">
</head>
<body>
<div class ="container">
    <nav>
        <ul class="menu">
            <a href="index.php"><li>Cadastro</li></a>
            <a href="Consultas.php"><li>Consultas</li></a>
            <a href="Alteracao.php"><li>Alteracao</li></a>
            <a href="Exclusao.php"><li>Exclusão</li></a>

        </ul>
    </nav>
    <section>

        EXCLUÍDO COM SUCESSO!!!

    </section>
</div>
</body>
</html>>