
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>WEB2</title>
    <link rel="stylesheet" href="_css/estilo.css">
</head>
<body>
<div class ="container">
    <nav>
        <ul class="menu">
            <a href="index.php"><li>Cadastro</li></a>
            <a href="Consultas.php"><li>Consultas</li></a>
            <a href="Alteracao.php"><li>Alteracao</li></a>
            <a href="Exclusao.php"><li>Exclusão</li></a>

        </ul>
    </nav>
    <section>
        <h1>Consulta</h1>
        <hr><br><br>

        <form method="POST" action="pesquisar.php">
            <input type="submit" value="ENVIAR" class="btn">
                <br><br>

                Descrição:<br>
                <input type="text" name="pesquisar" class="campo" maxlength="40" required autofocus><br>
            <br><br>



        </form>
    </section>
</div>
</body>
</html>
