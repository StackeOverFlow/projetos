<?php

    include_once("conexao.php");

    $nome = $_POST['nome'];

    $sql = "insert into usuarios (nome) values ('$nome')";
    $salvar = mysqli_query($conexao, $sql);

    $linhas = mysqli_affected_rows($conexao);

    mysqli_close($conexao);

?>


<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>WEB2</title>
    <link rel="stylesheet" href="_css/estilo.css">
</head>
<body>
<div class ="container">
    <nav>
        <ul class="menu">
            <a href="index.php"><li>Cadastro</li></a>
            <a href="Consultas.php"><li>Consultas</li></a>
            <a href="Alteracao.php"><li>Alteracao</li></a>
            <a href="Exclusao.php"><li>Exclusão</li></a>

        </ul>
    </nav>
    <section>
        <h1>Confirmação de cadastro</h1>
        <hr><br><br>

        <?php
            if($linhas == 1){
                print "Cadastro efetuado com sucesso!";
            }else{
                print"Cadastro não efetuado.";
            }
        ?>
        </form>
    </section>
</div>
</body>
</html>

